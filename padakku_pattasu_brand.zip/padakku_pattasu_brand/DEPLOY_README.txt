PADAKKU PATTASU - BRAND SITE (SELF-CONTAINED)
=============================================

This build is self-contained at base path /padakku_pattasu_brand/.
It does NOT depend on the /padakku_pattasu/ folder.

Upload the CONTENTS of this folder into the server directory served at
https://www.webwala.co.in/padakku_pattasu_brand/

Checklist
---------
1. Upload all files/folders here, preserving structure.
2. api/.env holds PRODUCTION settings (DB wwwwebwa_padakku_brand,
   CORS for webwala.co.in). Confirm they match the live server.
3. First-time DB setup only: visit
   https://www.webwala.co.in/padakku_pattasu_brand/api/setup.php  (once).
4. SECURITY: change the admin password after first sign-in (phone 9994033148).
5. Frontend calls the API at:
   https://www.webwala.co.in/padakku_pattasu_brand/api/v1

Not included: dev backups, tools/, local dev server file, SQL dumps,
and the local price-list JSON.